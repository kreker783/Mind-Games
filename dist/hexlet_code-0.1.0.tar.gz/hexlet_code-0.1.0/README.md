# Mind-Games

<a href="https://codeclimate.com/github/kreker783/Mind-Games/maintainability"><img src="https://api.codeclimate.com/v1/badges/c78e4a052e8ca4c97b20/maintainability" /></a>

Brain-even game demo:
https://asciinema.org/a/603130


Brain-calc game demo:
https://asciinema.org/a/603219


Brain-gcd game demo:
https://asciinema.org/a/vTc4NUpUrk6MkNlvmPYr3Plsb
