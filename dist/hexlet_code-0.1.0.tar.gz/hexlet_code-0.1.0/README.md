# Mind-Games

<a href="https://codeclimate.com/github/kreker783/Mind-Games/maintainability"><img src="https://api.codeclimate.com/v1/badges/c78e4a052e8ca4c97b20/maintainability" /></a>

How to launch brain-even game:
https://asciinema.org/a/603130
